# Netflix Intro Animation Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/claudio_bonfati/pen/mdryxPv](https://codepen.io/claudio_bonfati/pen/mdryxPv).

